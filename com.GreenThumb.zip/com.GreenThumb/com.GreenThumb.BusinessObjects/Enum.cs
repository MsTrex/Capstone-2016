﻿namespace com.GreenThumb.BusinessObjects
{
    public enum Active
    {
        active,
        inactive,
        all
    }
}
