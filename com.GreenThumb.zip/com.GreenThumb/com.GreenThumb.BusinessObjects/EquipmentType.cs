﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace com.GreenThumb.BusinessObjects
{
    public enum EquipmentType
    {
        TILLER,
        HOE,
        RAKE,
        SHOVEL,
        GLOVES,
        HOSE,
        WHEEL_BARROW

    }
}