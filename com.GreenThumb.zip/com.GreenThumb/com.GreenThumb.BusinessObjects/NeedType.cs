﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace com.GreenThumb.BusinessObjects
{
    public enum NeedType
    {
        TRELLIS_CONSTRUCTION,
        SHED_CONSTRUCTION,
        FENCE_CONSTRUCTION,
        EQUIPMENT,
        EQUIPMENT_REPAIR
    }
}