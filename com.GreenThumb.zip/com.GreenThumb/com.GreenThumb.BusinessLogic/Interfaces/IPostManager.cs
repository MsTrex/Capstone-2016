﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Interfaces
{
    public interface IPostManager
    {
        //IEnumerable<Post> RefreshPosts();
        //bool CreatePost(Post post);
        //bool DeletePost(Post post);
        //bool EditPost(Post post);
        //bool AddComment(Comment comment);
    }
}
