﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Interfaces
{
    public interface IMessageManager
    {
        //IEnumerable<Message> Inbox { get; }

        //bool SendMessage(Message message);
        //bool DeleteMessage(Message message);
        //bool DeleteMessages(IEnumerable<Message> messages);
        //bool MarkRead(Message message);
        //bool MarkRead(IEnumerable<Message> messages);
    }
}
