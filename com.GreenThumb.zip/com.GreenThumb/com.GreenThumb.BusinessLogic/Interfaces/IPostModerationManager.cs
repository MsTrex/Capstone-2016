﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Interfaces
{
    public interface IPostModerationManager
    {
        //bool EditPost(Post post);
        //bool RemovePost(Post post);
        //bool RemoveComment(Comment comment);
        //bool WipeComments(Post post);
        //bool LockPostComments(Post post);
        //bool HidePost(Post post);
    }
}
