﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Interfaces
{
    public interface IProfileManager
    {
        bool EditProfileInformation();
        //bool ChangeProfilePicture(ProfileImage profileImage);
        //bool ChangePreferences(Preferences preferences);
    }
}
