﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Interfaces
{
    public interface IRequestStatusManager
    {
        //IEnumerable<Request> RetrievePendingRequests();
        //bool ApproveRequest(Request request);
        //bool DeclineRequest(Request request);
    }
}
