﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Interfaces
{
    public interface IWorkTaskAssignmentManager
    {
        //IEnumerable<WorkTask> AssignedWorkTasks { get; }

        //bool AssignWorkTask(User user, WorkTask workTask);
        //bool RemoveAssignedWorkTask(User user, WorkTask workTask);
        //bool AssignMulitpleToWorkTask(IEnumerable<User> users, WorkTask workTask);
    }
}
