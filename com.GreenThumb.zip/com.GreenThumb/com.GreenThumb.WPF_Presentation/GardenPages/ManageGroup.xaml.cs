﻿using com.GreenThumb.BusinessLogic;
using com.GreenThumb.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace com.GreenThumb.WPF_Presentation.GardenPages
{
    /// <summary>
    /// Interaction logic for ManageGroup.xaml
    /// </summary>
    public partial class ManageGroup : Page
    {
        GroupManager _grpManager = new GroupManager();
        string originalGroupName;
        Group _group;

        public ManageGroup(AccessToken _accessToken, Group group)
        {
            InitializeComponent();
            _group = group;
            txtGroupName.Text = group.Name;
            originalGroupName = txtGroupName.Text;
        }

        private void btnGroupNameChange_Click(object sender, RoutedEventArgs e)
        {
            txtGroupName.IsEnabled = true;
            txtGroupName.Focus();
            txtGroupName.SelectAll();
            btnGroupNameChange.Visibility = Visibility.Hidden;
            btnGroupNameApply.Visibility = Visibility.Visible;
            btnGroupNameCancel.Visibility = Visibility.Visible;
        }

        private void btnGroupNameCancel_Click(object sender, RoutedEventArgs e)
        {
            txtGroupName.Text = _group.Name;
            btnGroupNameChange.Visibility = Visibility.Visible;
            btnGroupNameApply.Visibility = Visibility.Hidden;
            btnGroupNameCancel.Visibility = Visibility.Hidden;
            txtGroupName.IsEnabled = false;
        }

        private void btnGroupNameApply_Click(object sender, RoutedEventArgs e)
        {
            btnGroupNameChange.Visibility = Visibility.Visible;
            btnGroupNameApply.Visibility = Visibility.Hidden;
            btnGroupNameCancel.Visibility = Visibility.Hidden;
            txtGroupName.IsEnabled = false;
            if (!txtGroupName.Text.Equals("") || !txtGroupName.Text.Equals(_group.Name))
            {
                try
                {
                    _grpManager.ChangeGroupName(_group.GroupID, txtGroupName.Text, _group.Name);
                    _group.Name = txtGroupName.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }


    }
}
